import{I as o}from"./features-animation-jTYLkalm.js";import"./chunk-CNTMWM4F-CuLgX0yl.js";import"./index-BrJloaBZ.js";var m=o;export{m as default};
