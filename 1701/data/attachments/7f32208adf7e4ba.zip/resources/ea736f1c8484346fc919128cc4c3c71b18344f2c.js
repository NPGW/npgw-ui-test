import{I as o}from"./features-animation-BehhTluT.js";import"./chunk-CNTMWM4F-CHjEuLgV.js";import"./index-CLSqqfFp.js";var m=o;export{m as default};
