import{I as o}from"./features-animation-DP7RGhSL.js";import"./chunk-CNTMWM4F-eqqijTUT.js";import"./index-DcT943KD.js";var m=o;export{m as default};
