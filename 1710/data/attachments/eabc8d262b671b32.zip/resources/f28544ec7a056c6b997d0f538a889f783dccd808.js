import{I as o}from"./features-animation-D24c4IQP.js";import"./chunk-CNTMWM4F-D-NKn8dU.js";import"./index-CsY91oUC.js";var m=o;export{m as default};
