import{I as o}from"./features-animation-BJjS-IQb.js";import"./chunk-CNTMWM4F-B5CIb_YK.js";import"./index-CsxjLrAt.js";var m=o;export{m as default};
