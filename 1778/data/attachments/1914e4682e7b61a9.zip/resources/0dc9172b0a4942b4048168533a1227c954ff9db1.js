import{I as o}from"./features-animation-BjfFt0YX.js";import"./chunk-CNTMWM4F-DAo2Vz6m.js";import"./index-45rjVaed.js";var m=o;export{m as default};
