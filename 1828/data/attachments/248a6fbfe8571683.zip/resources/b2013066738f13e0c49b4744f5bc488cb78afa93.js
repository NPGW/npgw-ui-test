import{I as o}from"./features-animation-Bqi4-ifS.js";import"./chunk-CNTMWM4F-ouTSKsbs.js";import"./index-BVaAEJ6m.js";var m=o;export{m as default};
