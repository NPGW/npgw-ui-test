import{I as o}from"./features-animation-DA6LIHzY.js";import"./chunk-CNTMWM4F-Dzmv6T7H.js";import"./index-DxdngMli.js";var m=o;export{m as default};
