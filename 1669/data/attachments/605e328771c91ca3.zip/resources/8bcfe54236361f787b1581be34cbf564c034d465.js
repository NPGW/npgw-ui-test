const o="/assets/logo-DGAIZqcW.png";export{o as L};
