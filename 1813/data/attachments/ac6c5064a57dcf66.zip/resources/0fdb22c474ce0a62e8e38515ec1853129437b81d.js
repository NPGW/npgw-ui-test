import{I as o}from"./features-animation-DfRtaOqJ.js";import"./chunk-CNTMWM4F-BiaZs_i9.js";import"./index-Dk0XPfwJ.js";var m=o;export{m as default};
